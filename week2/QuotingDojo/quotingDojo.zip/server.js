const express = require("express"),
    app = express(),
    port = 8000,
    server = app.listen(port,() => console.log(`Listening on port ${port}`));
const session = require('express-session');
const flash = require('express-flash');
const mongoose = require("mongoose");
mongoose.connect('mongodb://localhost/Quotes', {useNewUrlParser: true})

const QuoteSchema = new mongoose.Schema({
    name: {type: String, required: true},
    quote: {type: String, required: true}
}, {timestamps: true})

const Quote = mongoose.model("Quote", QuoteSchema)

app.use(express.urlencoded({extended: true}));
app.use(express.static(__dirname+ "/static"));
app.use(flash());
app.set("view engine", "ejs");
app.set("views",__dirname+ "/views");

app.use(session({
    secret: "keyboardkitteh",
    resave: false,
    saveUninitialized: true,
    cookie: {maxAge : 6000}
}))

app.get('/', (req,res) => {
    res.render("index");
})

app.post('/quotes', (req,res) =>{
    const quote = new Quote();
    quote.name = req.body.name
    quote.quote = req.body.quote
    quote.save()
    .then(data => {
        res.redirect("quotes")
    })
    .catch(err => {
        console.log("err:", err)
        for (var key in err.errors) {
            req.flash('registration', err.errors[key].message);
        }
        res.redirect("/")
    })
});

app.get("/quotes", (req,res) =>{
    quotes = Quote.find().sort({createdAt: -1})
    .then(data => {
        res.render("quotes", {quotes: data})
    })
});