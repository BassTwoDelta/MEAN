const mongoose = require("mongoose");
mongoose.connect('mongodb://localhost/Otters', {useNewUrlParser: true})