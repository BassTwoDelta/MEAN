const express = require("express"),
    app = express(),
    port = 8000,
    server = app.listen(port,() => console.log(`Listening on port ${port}`));
const session = require('express-session');
const flash = require('express-flash');
const mongoose = require("mongoose");
mongoose.connect('mongodb://localhost/Otters', {useNewUrlParser: true})

const OtterSchema = new mongoose.Schema({
    name: {type: String, required: true},
    age: {type: Number, required: true},
    location : {type: String, required: true},
    description : {type: String, required: false}
})

const Otter = mongoose.model("Otter", OtterSchema)

app.use(express.urlencoded({extended: true}));
app.use(express.static(__dirname+ "/static"));
app.use(flash());
app.use(session({
    secret: "keyboardkitteh",
    resave: false,
    saveUninitialized: true,
    cookie: {maxAge : 6000}
}));

app.set("view engine", "ejs");
app.set("views",__dirname+ "/views");

app.get("/", (req,res) => {
    otters = Otter.find()
    .then(data => {
        res.render('index', {otters: data})
    })
});

app.get("/otters/new", (req, res) => {
    res.render("newOtter");
})

app.get("/otters/:id", (req, res) => {
    otter = Otter.findById(req.params.id)
    .then(data => {
        res.render("otter", {otter:data})
    })
})

app.get("/otters/edit/:id",(req, res)=>{
    otter = Otter.findById(req.params.id)
    .then(data => {
        res.render("editOtter", {otter:data})
    })
})

app.post("/otters/delete/:id", (req, res)=> {
    otter = Otter.findById(req.params.id)
    otter.remove()
    .then(data => {
        res.redirect("/")
    })
})

app.post("/otters", (req, res) => {
    const otter = new Otter();
    otter.name = req.body.name
    otter.age = req.body.age
    otter.location = req.body.location
    otter.description = req.body.description
    otter.save()
    .then(data => {
        res.redirect("/")
    })
    .catch(err => {
        console.log("err:", err)
        for (var key in err.errors) {
            req.flash('registration', err.errors[key].message);
        }
        res.redirect("/otters/new")
    })
})

app.post("/otters/update/:id", (req, res)=> {
    otter = Otter.findById(req.params.id)
    otter.update({name: req.body.name, age: req.body.age, location: req.body.location, description: req.body.description})
    .then(data => {
        res.redirect(`/otters/${req.params.id}`)
    })
    .catch(err => {
        console.log("err:", err)
        for (var key in err.errors) {
            req.flash('registration', err.errors[key].message);
        }
        res.redirect(`/otters/edit/${req.params.id}`)
    })
})
// app.get("/otters/:id", (req,res) => {
//     otter = Otter.findById(req.params.id)
// })
