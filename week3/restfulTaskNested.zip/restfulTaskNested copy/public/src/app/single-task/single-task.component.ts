import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-single-task',
  templateUrl: './single-task.component.html',
  styleUrls: ['./single-task.component.scss']
})
export class SingleTaskComponent implements OnInit {
  
  @Input()singleTask
  constructor() { }

  ngOnInit() {
  }

}
